#!/usr/bin/env python  

from operator import itemgetter
import sys

current_all_keys = None
current_value = 0
counter  = 0
logType = sys.argv[1] 
field = sys.argv[2] 
args = sys.argv[3].split('.')[0]       


# input comes from STDIN
for line in sys.stdin: 
     
    # remove leading and trailing whitespace
    line = line.strip()
    all_keys, value = line.split('\t')  
    # convert count (currently a string) to int
    try:
        if "302" in args:   
            keys = args.split('_')   
            well_name   = keys[0].replace("-", "")
            operation = keys[2] 
            
            date_items =  keys[3].split('-') 
            date   = date_items[2]+"-"+ date_items[1]+"-"+date_items[0]
        else: 
            keys = args.split('_') 
            operation = keys[0]
            well_name   = keys[1].replace("-", "")
            
            date_items =  keys[2].split('-') 
            date   = date_items[2]+"-"+ date_items[1]+"-"+date_items[0]
              
        value = float(value) 
    except ValueError:
        # count was not a number, so silently
        # ignore/discard this line
        continue

    # this IF-switch only works because Hadoop sorts map output
    # by key (here: word) before it is passed to the reducer
    if current_all_keys == all_keys:
        current_value += value  
        counter += 1 
    else:
        if current_all_keys:
            # write result to STDOUT
            print '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s' % (logType,field,
                          well_name,
                          date,
                          operation,
                          current_all_keys.split('_')[1],
                          current_all_keys.split('_')[0],
                          current_value/counter)
        current_value = value  
        current_all_keys = all_keys
        counter = 1

# do not forget to output the last word if needed!
if current_all_keys == all_keys:
    print '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s' % (logType,field,
                          well_name,
                          date,
                          operation,
                          current_all_keys.split('_')[1],
                          current_all_keys.split('_')[0],
                          current_value) 