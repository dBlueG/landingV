#!/usr/bin/env python                                                              
"""volve_log_mapper.py"""                                                          
                                                                                   
from operator import itemgetter                                                    
import sys                                                                         
import subprocess                                                                  
                                                                                   
well_name = None                                                                   
start = None                                                                       
stop = None                                                                        
step = None                                                                        
date = None                                                                        
null = None                                                                        
size = None                                                                        
stage = 'WELL_INFORMATION'                                                         
curve = []                                                                         
buff = None                                                                        
current_depth = None                                                                
                                                                                   
                                               
for line in sys.stdin:                                                       
    # remove leading and trailing whitespace                                    
    line = line.strip()                                                         
    # split the line into words                                                 
    words = line.split()                                                        
                                                                                
    if line.startswith('#'):                                                    
        continue                                                                
                                                                                
    if line.startswith('~'):                                                    
        if 'CURVE INFORMATION' in line.upper():                                 
            if (well_name is  None or                                           
                step is  None or                                                
                start is None or                                                
                stop is None or                                                 
                date is  None or                                                
                null is  None ):                                                
                break                                                           
            well_name = well_name.strip()                                       
            well_name = well_name.replace(" ","_")                              
            well_name = well_name.replace("/","_")                              
            well_name = well_name.replace("-","_")                              
            buff  = step *10                                                    
            current_depth = round(start + buff,0)                               
            stage = 'CURVE_INFORMATION'                                         
            continue                                                            
                                                                                
        elif stage == 'CURVE_INFORMATION':                                      
            stage = 'OTHER_INFORMATION'                                         
            size = len(curve)                                                   
            continue                                                            
                                                                                
        continue                                                                
                                                                                
    if(stage == 'WELL_INFORMATION'):                                            
        if ( words[0].upper().startswith('WELL')):                              
            well_name = [x for x in words if ':' in x][0][:-1]                  
                                                                                
        elif ( words[0].upper().startswith('STEP')):                            
            step = float([x for x in words if ':' in x][0][:-1])                
                                                                                
        elif ( words[0].upper().startswith('DATE')):                            
            date = [x for x in words if ':' in x][0][:-1]                       
                                                                                
        elif ( words[0].upper().startswith('NULL')):                            
            null =  ([x for x in words if ':' in x][0][:-1])                    
                                                                                
        elif ( words[0].upper().startswith('STRT')):                            
            start = float([x for x in words if ':' in x][0][:-1])               
                                                                                
        elif ( words[0].upper().startswith('STOP')):                            
            stop = float([x for x in words if ':' in x][0][:-1])                
                                                                                
    elif(stage == 'CURVE_INFORMATION') :                                        
        keyword = words[0]                                                      
                                                                                
        if '-' in words[0]:                                                     
            keyword = (keyword.split('-')[1])                                   
        elif '_' in words[0]:                                                   
            keyword = (keyword.split('_')[1])                                   
                                                                                
        if '.' in words[0]:                                                     
            keyword = keyword.split('.')[0]                                     
        curve.append(keyword)                                                   
                                                                                
                                                                                
    elif(stage == 'OTHER_INFORMATION') :                                         
        if(not words[0].isdigit() and                                           
        len(words) != size):                                                    
            continue                                                            
                                                                                
        for i in range(size):                                                   
            if i ==0 :                                                          
                continue                                                        
                                                                                
            try:                                                                
                if float(words[i]) < 0 :                                        
                    continue                                                    
            except ValueError:                                                  
                continue                                                        
                                                                                
            if (  float(words[0]) > current_depth):                             
                current_depth = int(round(current_depth + buff,0))              
                                                                                 
            print '%s\t%s' % ( str(curve[i])+"_"+str(current_depth), words[i])